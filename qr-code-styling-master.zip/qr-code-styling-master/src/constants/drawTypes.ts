import { DrawTypes } from "../types";

export default {
  canvas: "canvas",
  svg: "svg"
} as DrawTypes;
