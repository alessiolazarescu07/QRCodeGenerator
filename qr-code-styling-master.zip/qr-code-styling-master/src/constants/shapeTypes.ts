import { ShapeTypes } from "../types";

export default {
  square: "square",
  circle: "circle"
} as ShapeTypes;
