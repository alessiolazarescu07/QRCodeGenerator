import { CornerDotTypes } from "../types";

export default {
  dot: "dot",
  square: "square"
} as CornerDotTypes;